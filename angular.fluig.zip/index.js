'use strict';

var moduleName = require('./src/angular-fluig.js');

module.exports = moduleName;